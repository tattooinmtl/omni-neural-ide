class Data: pass
