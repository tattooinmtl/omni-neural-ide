OMNI-CODE v1.0.2
Install: %USERPROFILE%\.omni-neural-ide
Native Win32 launcher (logo splash, green UI). API keys: Settings → Providers.
