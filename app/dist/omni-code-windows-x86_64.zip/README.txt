OMNI-CODE v1.0.1
================

Install root (per-user): %USERPROFILE%\.omni-neural-ide

  bin\launcher.exe          native Win32 launcher (no browser)
  bin\omni-core.exe         Rust core + native WebView2 window
  bin\WebView2Loader.dll    required (bundled)
  bin\libunwind.dll         required (bundled)
  ui\dist\                  prebuilt UI
  fixtures\                 demo projects
  keys\                     API keys (local only)
  logs\                     launcher.log / omni-core.log
  webview2\                 WebView2 user data

First run: enter MiniMax and NVIDIA keys in the launcher, pick Plain or Ultra.
