OMNI-CODE v1.0
==============

Installed layout:
  bin\launcher.exe     - start here (asks Plain vs Ultra)
  bin\omni-core.exe    - Rust core + native WebView2 window
  ui\dist\             - prebuilt UI (no npm needed)
  fixtures\            - demo projects
  keys\                - your MiniMax / NVIDIA API keys (local only)
  sandbox\             - harness sandbox

First run: enter MiniMax and NVIDIA API keys in the launcher.
