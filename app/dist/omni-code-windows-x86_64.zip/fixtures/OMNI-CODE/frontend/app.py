# static frontend helper
